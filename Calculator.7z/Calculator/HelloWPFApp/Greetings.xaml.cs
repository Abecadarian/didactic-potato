﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace HelloWPFApp
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        bool userIsInMiddleofTypingaNumber = false;
        Stack<string> Operands = new Stack<string>();
        Stack<string> Operations = new Stack<string>();
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Number(object sender, RoutedEventArgs e)
        {
            Button btn = (Button)sender;
            if (!userIsInMiddleofTypingaNumber)
            {
                userIsInMiddleofTypingaNumber = true;
                Display.Text = btn.Content.ToString();
            }
            else
            {
                Display.Text = Display.Text + btn.Content.ToString();
            }

        }

        private void BinaryOperation(object sender, RoutedEventArgs e)
        {
                if (userIsInMiddleofTypingaNumber)
                {
                    Button btn = (Button)sender;
                    string Operation = btn.Content.ToString();
                    Operations.Push(Operation);
                    Operands.Push(Display.Text);
                    Display.Text = Operation;
                }
                userIsInMiddleofTypingaNumber = false;
            }

        private void result(object sender, RoutedEventArgs e)
        {
            if (userIsInMiddleofTypingaNumber) { 
            Operands.Push(Display.Text);
            if ((Operands.Count > 0) && (Operations.Count > 0)) {
                string Operation = Operations.Pop();
                double Operand1 = Convert.ToDouble(Operands.Pop());
                double result = 0;
                if ((Operands.Count > 0)) {
                    {
                        double Operand2 = Convert.ToDouble(Operands.Pop());
                        switch (Operation)
                        {
                            case "x":
                                result = Operand1 * Operand2;
                                break;
                            case "/":
                                result = Operand2 / Operand1;
                                break;
                            case "+":
                                result = (Operand1 + Operand2);
                                break;
                            case "-":
                                result = (Operand2 - Operand1);
                                break;
                            default: break;
                        }
                        Display.Text = System.Convert.ToString(result);
                    }
                }
            }
            }
        }
        private void Clear(object sender, RoutedEventArgs e)
        {
            Operations.Clear();
            Operands.Clear();
            Display.Text = "0";
            userIsInMiddleofTypingaNumber = false;
        }
    }
}
